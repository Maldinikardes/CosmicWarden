package com.yourname.cosmicwarden;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(
                    ForgeRegistries.ENTITY_TYPES,
                    CosmicWarden.MOD_ID
            );

    public static final RegistryObject<EntityType<CosmicWardenEntity>> COSMIC_WARDEN =
            ENTITIES.register("cosmic_warden",
                    () -> EntityType.Builder.of(
                            CosmicWardenEntity::new,
                            MobCategory.MONSTER
                    )
                    .sized(1.5f, 3.0f)
                    .build("cosmic_warden"));
}