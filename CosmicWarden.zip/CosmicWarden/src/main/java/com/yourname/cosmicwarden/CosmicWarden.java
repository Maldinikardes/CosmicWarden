package com.yourname.cosmicwarden;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CosmicWarden.MOD_ID)
public class CosmicWarden {
    public static final String MOD_ID = "cosmicwarden";

    public CosmicWarden() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
    }
}