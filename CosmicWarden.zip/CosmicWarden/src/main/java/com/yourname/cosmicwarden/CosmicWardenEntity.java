package com.yourname.cosmicwarden;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

public class CosmicWardenEntity extends Monster {

    public CosmicWardenEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }
}